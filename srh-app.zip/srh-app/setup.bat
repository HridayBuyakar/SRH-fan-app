@echo off
echo.
echo  ==========================================
echo   SRH Fan App - First-Time Setup
echo  ==========================================
echo.

:: ── Backend ──────────────────────────────────
echo [1/4] Creating Python virtual environment...
cd backend
C:\Python313\python.exe -m venv venv
if errorlevel 1 (
    echo ERROR: Could not create venv. Is Python 3.13 installed at C:\Python313\?
    pause
    exit /b 1
)

echo [2/4] Installing Python dependencies...
call venv\Scripts\activate.bat
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo ERROR: pip install failed.
    pause
    exit /b 1
)

:: Create .env from example if it doesn't exist
if not exist .env (
    copy .env.example .env >nul
    echo [2/4] Created backend\.env  ^(add CRICKETDATA_API_KEY when you have one^)
)

call venv\Scripts\deactivate.bat
cd ..

:: ── Frontend ─────────────────────────────────
echo [3/4] Installing frontend dependencies...
cd frontend
call npm install --silent
if errorlevel 1 (
    echo ERROR: npm install failed. Is Node.js installed?
    pause
    exit /b 1
)
cd ..

echo.
echo  ==========================================
echo   Setup complete!
echo   Run start.bat to launch the app.
echo  ==========================================
echo.
pause
