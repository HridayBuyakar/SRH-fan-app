import { useState } from 'react'
import { useApi } from '../hooks/useApi'
import PlayerCard from '../components/PlayerCard'
import { SkeletonCard } from '../components/Skeleton'

const ROLE_FILTERS = ['All', 'Batter', 'Bowler', 'All-Rounder', 'WK-Batter']

const ROLE_ACCENT = {
  'Batter': '#FACC15',
  'Bowler': '#60A5FA',
  'All-Rounder': '#FF6B00',
  'WK-Batter': '#C084FC',
}

function PlayerRow({ player, onClick }) {
  const accent = ROLE_ACCENT[player.role] || '#8A8A8A'
  const s = player.t20_stats

  return (
    <button
      onClick={onClick}
      className="w-full srh-card p-4 text-left group"
    >
      <div className="flex items-center gap-4">
        {/* Jersey number */}
        <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: `${accent}18`, border: `1px solid ${accent}40` }}>
          <span className="font-mono text-sm font-medium" style={{ color: accent }}>
            {player.jersey_number ? `#${player.jersey_number}` : '—'}
          </span>
        </div>

        {/* Name & meta */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-display text-xl tracking-wider text-white group-hover:text-srh-orange transition-colors">
              {player.name.toUpperCase()}
            </span>
            {player.is_captain && <span className="text-xs text-srh-gold">©</span>}
            {player.is_overseas && <span className="text-xs text-srh-ash">🌏</span>}
          </div>
          <div className="flex items-center gap-2 mt-0.5 text-xs text-srh-ash">
            <span style={{ color: accent }}>{player.role}</span>
            <span className="text-srh-charcoal-border">•</span>
            <span>{player.nationality}</span>
            {player.ipl_price_cr && (
              <>
                <span className="text-srh-charcoal-border">•</span>
                <span className="text-srh-gold font-mono">₹{player.ipl_price_cr}Cr</span>
              </>
            )}
          </div>
        </div>

        {/* Key stat */}
        <div className="text-right shrink-0">
          {player.role === 'Bowler' ? (
            <>
              <div className="font-mono text-white text-sm">{s.wickets} wkts</div>
              <div className="font-mono text-xs text-srh-ash">Eco {s.economy ?? '—'}</div>
            </>
          ) : (
            <>
              <div className="font-mono text-white text-sm">{s.runs} runs</div>
              <div className="font-mono text-xs text-srh-ash">SR {s.batting_sr}</div>
            </>
          )}
        </div>

        <span className="text-srh-charcoal-border group-hover:text-srh-orange transition-colors ml-1">›</span>
      </div>
    </button>
  )
}

export default function SquadPage() {
  const { data, loading } = useApi('/squad/')
  const [filter, setFilter] = useState('All')
  const [selected, setSelected] = useState(null)

  const squad = data?.squad || []
  const filtered = filter === 'All' ? squad : squad.filter(p => p.role === filter)

  const overseas = squad.filter(p => p.is_overseas).length
  const domestic = squad.filter(p => !p.is_overseas).length

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">

      {/* Hero header */}
      <div className="mb-8 flame-bg">
        <div className="flex items-end justify-between flex-wrap gap-4">
          <div>
            <p className="font-mono text-xs text-srh-orange tracking-widest mb-2">IPL 2026 · SEASON SQUAD</p>
            <h1 className="font-display text-6xl tracking-widest text-white leading-none">
              ORANGE<br />
              <span className="text-srh-orange animate-glow">ARMY</span>
            </h1>
          </div>
          <div className="flex gap-4 text-center">
            <div className="border border-srh-charcoal-border rounded-lg px-4 py-3">
              <div className="font-display text-3xl text-white">{squad.length}</div>
              <div className="text-xs text-srh-ash font-mono mt-1">PLAYERS</div>
            </div>
            <div className="border border-srh-charcoal-border rounded-lg px-4 py-3">
              <div className="font-display text-3xl text-srh-orange">{overseas}</div>
              <div className="text-xs text-srh-ash font-mono mt-1">OVERSEAS</div>
            </div>
            <div className="border border-srh-charcoal-border rounded-lg px-4 py-3">
              <div className="font-display text-3xl text-white">{domestic}</div>
              <div className="text-xs text-srh-ash font-mono mt-1">DOMESTIC</div>
            </div>
          </div>
        </div>
      </div>

      <div className="orange-divider mb-6" />

      {/* Role filters */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {ROLE_FILTERS.map(r => (
          <button
            key={r}
            onClick={() => setFilter(r)}
            className={`px-4 py-1.5 rounded-full text-sm font-body font-medium transition-all ${
              filter === r
                ? 'bg-srh-orange text-white'
                : 'border border-srh-charcoal-border text-srh-ash hover:text-white hover:border-white/30'
            }`}
          >
            {r}
            {r !== 'All' && (
              <span className="ml-1.5 text-xs opacity-60">
                {squad.filter(p => p.role === r).length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Player list */}
      <div className="flex flex-col gap-2">
        {loading
          ? Array(8).fill(0).map((_, i) => <SkeletonCard key={i} />)
          : filtered.map(player => (
            <PlayerRow
              key={player.id}
              player={player}
              onClick={() => setSelected(player)}
            />
          ))
        }
      </div>

      {/* Player modal */}
      {selected && (
        <PlayerCard player={selected} onClose={() => setSelected(null)} />
      )}
    </div>
  )
}
