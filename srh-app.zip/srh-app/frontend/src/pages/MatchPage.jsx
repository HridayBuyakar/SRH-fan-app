import { usePolling } from '../hooks/useApi'
import WeatherWidget from '../components/WeatherWidget'

function LiveDot() {
  return (
    <div className="flex items-center gap-2">
      <span className="w-2.5 h-2.5 rounded-full bg-red-500 score-live" />
      <span className="font-mono text-xs text-red-400 tracking-widest">LIVE</span>
    </div>
  )
}

function Scoreboard({ match }) {
  const teams = match.teamInfo || []
  const scores = match.score || []

  const getScore = (teamName) =>
    scores.find(s => s.inning?.toLowerCase().includes(teamName?.toLowerCase().slice(0, 8)))

  return (
    <div className="srh-card overflow-hidden">
      {/* Top bar */}
      <div className="px-5 py-3 border-b border-srh-charcoal-border flex items-center justify-between">
        <LiveDot />
        <span className="font-mono text-xs text-srh-ash truncate max-w-xs">{match.venue}</span>
        {match.toss && (
          <span className="font-mono text-xs text-srh-ash hidden sm:block">
            Toss: {match.toss.winner} ({match.toss.decision})
          </span>
        )}
      </div>

      {/* Match name */}
      <div className="px-5 pt-4 pb-2">
        <h2 className="font-display text-2xl tracking-wider text-white">{match.name}</h2>
      </div>

      {/* Scores */}
      <div className="px-5 pb-4 grid grid-cols-2 gap-4">
        {teams.map((team, i) => {
          const sc = getScore(team.shortname || team.name)
          const isSRH = team.shortname === 'SRH' || team.name?.toLowerCase().includes('sunrisers')
          return (
            <div key={i}
              className={`rounded-xl p-4 border ${
                isSRH
                  ? 'border-srh-orange/50 bg-srh-orange/10'
                  : 'border-srh-charcoal-border bg-srh-charcoal'
              }`}
            >
              <div className={`font-display text-lg tracking-widest mb-1 ${isSRH ? 'text-srh-orange' : 'text-srh-ash'}`}>
                {team.shortname || team.name}
              </div>
              {sc ? (
                <>
                  <div className="font-mono text-3xl text-white font-medium">
                    {sc.r}/{sc.w}
                  </div>
                  <div className="font-mono text-sm text-srh-ash mt-0.5">
                    {sc.o} overs
                    {sc.o > 0 && (
                      <span className="ml-2 text-srh-ash-light">
                        CRR {(sc.r / sc.o).toFixed(2)}
                      </span>
                    )}
                  </div>
                </>
              ) : (
                <div className="font-mono text-2xl text-srh-charcoal-border">Yet to bat</div>
              )}
            </div>
          )
        })}
      </div>

      {/* Status */}
      <div className="mx-5 mb-5 py-2.5 rounded-lg bg-srh-charcoal text-center">
        <p className="font-mono text-sm text-srh-orange font-medium">{match.status}</p>
      </div>

      {match.is_mock && (
        <div className="mx-5 mb-4 text-center">
          <span className="font-mono text-xs text-srh-ash border border-srh-charcoal-border px-3 py-1 rounded-full">
            ⚡ DEMO DATA — add CRICKETDATA_API_KEY to .env for live scores
          </span>
        </div>
      )}
    </div>
  )
}

function BattingTable({ batting }) {
  if (!batting?.length) return null
  return (
    <div className="srh-card overflow-hidden">
      <div className="px-5 py-3 border-b border-srh-charcoal-border">
        <h3 className="font-display text-xl tracking-widest text-white">BATTING</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-srh-charcoal-border">
              <th className="text-left px-5 py-2 font-mono text-xs text-srh-ash">BATTER</th>
              <th className="text-right px-4 py-2 font-mono text-xs text-srh-ash">R</th>
              <th className="text-right px-4 py-2 font-mono text-xs text-srh-ash">B</th>
              <th className="text-right px-4 py-2 font-mono text-xs text-srh-ash">4s</th>
              <th className="text-right px-4 py-2 font-mono text-xs text-srh-ash">6s</th>
              <th className="text-right px-5 py-2 font-mono text-xs text-srh-ash">SR</th>
            </tr>
          </thead>
          <tbody>
            {batting.map((b, i) => (
              <tr key={i} className="border-b border-srh-charcoal-border/50 hover:bg-srh-charcoal-border/20 transition-colors">
                <td className="px-5 py-3 font-body text-white">{b.batsman}</td>
                <td className="px-4 py-3 text-right font-mono text-srh-orange font-medium">{b.r}</td>
                <td className="px-4 py-3 text-right font-mono text-srh-ash">{b.b}</td>
                <td className="px-4 py-3 text-right font-mono text-white">{b['4s']}</td>
                <td className="px-4 py-3 text-right font-mono text-white">{b['6s']}</td>
                <td className="px-5 py-3 text-right font-mono text-srh-ash">{b.sr}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function BowlingTable({ bowling }) {
  if (!bowling?.length) return null
  return (
    <div className="srh-card overflow-hidden">
      <div className="px-5 py-3 border-b border-srh-charcoal-border">
        <h3 className="font-display text-xl tracking-widest text-white">BOWLING</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-srh-charcoal-border">
              <th className="text-left px-5 py-2 font-mono text-xs text-srh-ash">BOWLER</th>
              <th className="text-right px-4 py-2 font-mono text-xs text-srh-ash">O</th>
              <th className="text-right px-4 py-2 font-mono text-xs text-srh-ash">R</th>
              <th className="text-right px-4 py-2 font-mono text-xs text-srh-ash">W</th>
              <th className="text-right px-5 py-2 font-mono text-xs text-srh-ash">ECO</th>
            </tr>
          </thead>
          <tbody>
            {bowling.map((b, i) => (
              <tr key={i} className="border-b border-srh-charcoal-border/50 hover:bg-srh-charcoal-border/20 transition-colors">
                <td className="px-5 py-3 font-body text-white">{b.bowler}</td>
                <td className="px-4 py-3 text-right font-mono text-srh-ash">{b.o}</td>
                <td className="px-4 py-3 text-right font-mono text-srh-ash">{b.r}</td>
                <td className="px-4 py-3 text-right font-mono text-srh-orange font-medium">{b.w}</td>
                <td className="px-5 py-3 text-right font-mono text-srh-ash">{b.eco}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default function MatchPage() {
  // Poll every 30s to stay within 100 hits/day limit
  const { data, loading } = usePolling('/matches/live', 30000)

  const matches = data?.matches || []
  const currentMatch = matches[0] || null

  // Derive city from venue string for weather
  const getCity = (venue = '') => {
    const v = venue.toLowerCase()
    if (v.includes('bengaluru') || v.includes('bangalore')) return 'bengaluru'
    if (v.includes('kolkata')) return 'kolkata'
    if (v.includes('mumbai')) return 'mumbai'
    if (v.includes('chennai')) return 'chennai'
    if (v.includes('delhi')) return 'delhi'
    if (v.includes('jaipur')) return 'jaipur'
    if (v.includes('lucknow')) return 'lucknow'
    if (v.includes('ahmedabad')) return 'ahmedabad'
    if (v.includes('mohali')) return 'mohali'
    return 'hyderabad'
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">

      {/* Header */}
      <div className="mb-8">
        <p className="font-mono text-xs text-srh-orange tracking-widest mb-2">IPL 2026 · LIVE CENTRE</p>
        <h1 className="font-display text-5xl tracking-widest text-white">
          MATCH <span className="text-srh-orange">LIVE</span>
        </h1>
        <p className="text-srh-ash text-sm mt-2 font-mono">Refreshes every 30s · Free tier</p>
      </div>

      <div className="orange-divider mb-6" />

      {loading && !currentMatch && (
        <div className="srh-card p-10 text-center">
          <div className="font-display text-2xl text-srh-orange animate-pulse tracking-widest">LOADING...</div>
        </div>
      )}

      {currentMatch && (
        <div className="flex flex-col gap-4">
          <Scoreboard match={currentMatch} />

          {/* Weather for current match venue */}
          <div className="srh-card p-4">
            <p className="font-mono text-xs text-srh-ash tracking-widest mb-3">MATCH DAY CONDITIONS</p>
            <WeatherWidget city={getCity(currentMatch.venue)} />
          </div>

          <BattingTable batting={currentMatch.batting} />
          <BowlingTable bowling={currentMatch.bowling} />
        </div>
      )}

      {!loading && !currentMatch && (
        <div className="srh-card p-12 text-center">
          <div className="text-5xl mb-4">🏏</div>
          <div className="font-display text-3xl tracking-widest text-white mb-2">NO MATCH IN PROGRESS</div>
          <p className="text-srh-ash font-mono text-sm">Check the Schedule for upcoming SRH fixtures</p>
        </div>
      )}
    </div>
  )
}
