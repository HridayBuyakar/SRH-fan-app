import { useApi } from '../hooks/useApi'
import WeatherWidget from '../components/WeatherWidget'
import { SkeletonCard } from '../components/Skeleton'

function Countdown({ dateStr, timeIst }) {
  const matchDate = new Date(`${dateStr}T${timeIst}:00+05:30`)
  const now = new Date()
  const diff = matchDate - now

  if (diff <= 0) return <span className="text-srh-ash font-mono text-xs">MATCH DAY</span>

  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

  if (days > 0) return (
    <span className="font-mono text-xs text-srh-orange">
      {days}d {hours}h away
    </span>
  )
  return (
    <span className="font-mono text-xs text-srh-gold animate-pulse">
      {hours}h {mins}m away
    </span>
  )
}

function MatchCard({ match, isNext }) {
  const cityKey = match.city.toLowerCase().replace(/\s+/g, '-')
  const isHome = match.is_home

  const statusColors = {
    upcoming: 'text-srh-ash border-srh-ash/30',
    today: 'text-srh-gold border-srh-gold/40 bg-srh-gold/10',
    completed: 'text-srh-charcoal-border border-srh-charcoal-border/40',
  }

  return (
    <div className={`srh-card overflow-hidden ${isNext ? 'border-srh-orange/60 shadow-[0_0_30px_rgba(255,107,0,0.15)]' : ''}`}>

      {/* Next match banner */}
      {isNext && (
        <div className="bg-srh-orange px-5 py-1.5 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-white score-live" />
          <span className="font-display tracking-widest text-white text-sm">NEXT MATCH</span>
        </div>
      )}

      <div className="p-5">
        {/* Top row: match number, date, status */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs text-srh-ash">Match #{match.match_number}</span>
            <span className={`font-mono text-xs px-2 py-0.5 rounded border capitalize ${statusColors[match.status]}`}>
              {match.status}
            </span>
            {isHome ? (
              <span className="font-mono text-xs text-green-400 border border-green-400/30 bg-green-400/10 px-2 py-0.5 rounded">HOME</span>
            ) : (
              <span className="font-mono text-xs text-srh-ash border border-srh-charcoal-border px-2 py-0.5 rounded">AWAY</span>
            )}
          </div>
          {match.status === 'upcoming' && (
            <Countdown dateStr={match.date} timeIst={match.time_ist} />
          )}
        </div>

        {/* Teams */}
        <div className="flex items-center justify-between mb-4">
          {/* SRH */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-srh-orange/20 border border-srh-orange/40 flex items-center justify-center">
              <span className="font-display text-lg text-srh-orange">SRH</span>
            </div>
            <div>
              <div className="font-display text-2xl tracking-wider text-white">SUNRISERS</div>
              <div className="font-mono text-xs text-srh-orange">HYDERABAD</div>
            </div>
          </div>

          {/* VS / Score */}
          <div className="text-center px-4">
            {match.score_srh ? (
              <div>
                <div className="font-mono text-lg text-white font-medium">{match.score_srh}</div>
                <div className="font-display text-sm text-srh-ash">VS</div>
                <div className="font-mono text-lg text-white font-medium">{match.score_opp}</div>
              </div>
            ) : (
              <div className="font-display text-xl text-srh-charcoal-border tracking-widest">VS</div>
            )}
          </div>

          {/* Opponent */}
          <div className="flex items-center gap-3 flex-row-reverse text-right">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: `${match.opponent_color}20`, border: `1px solid ${match.opponent_color}60` }}>
              <span className="font-display text-sm font-bold" style={{ color: match.opponent_color }}>
                {match.opponent_short}
              </span>
            </div>
            <div>
              <div className="font-display text-xl tracking-wider text-white">{match.opponent_short}</div>
              <div className="font-mono text-xs text-srh-ash">{match.opponent.split(' ').slice(-1)[0].toUpperCase()}</div>
            </div>
          </div>
        </div>

        {/* Result banner */}
        {match.result && (
          <div className={`text-center py-1.5 rounded-lg mb-4 font-mono text-sm ${
            match.result.includes('SRH') || match.result.includes('Sunrisers')
              ? 'bg-green-500/10 border border-green-500/30 text-green-400'
              : 'bg-red-500/10 border border-red-500/30 text-red-400'
          }`}>
            {match.result}
          </div>
        )}

        {/* Venue + date */}
        <div className="orange-divider mb-3" />
        <div className="flex items-center justify-between text-xs text-srh-ash">
          <div className="flex items-center gap-1.5">
            <span>📍</span>
            <span>{match.venue}</span>
          </div>
          <div className="font-mono">
            {new Date(match.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
            {' · '}
            {match.time_ist} IST
          </div>
        </div>

        {/* Weather — show for upcoming matches */}
        {match.status !== 'completed' && (
          <div className="mt-3">
            <WeatherWidget city={match.city.toLowerCase().split(' ')[0]} />
          </div>
        )}
      </div>
    </div>
  )
}

export default function SchedulePage() {
  const { data, loading } = useApi('/schedule/')

  const schedule = data?.schedule || []
  const upcoming = schedule.filter(m => m.status !== 'completed')
  const completed = schedule.filter(m => m.status === 'completed')
  const nextMatch = upcoming[0] || null

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">

      {/* Header */}
      <div className="mb-8">
        <p className="font-mono text-xs text-srh-orange tracking-widest mb-2">IPL 2026 · SEASON SCHEDULE</p>
        <h1 className="font-display text-5xl tracking-widest text-white">
          MATCH <span className="text-srh-orange">CALENDAR</span>
        </h1>
        <div className="flex gap-6 mt-4 text-sm text-srh-ash">
          <span><span className="text-white font-medium">{upcoming.length}</span> upcoming</span>
          <span><span className="text-white font-medium">{completed.length}</span> played</span>
          <span>
            <span className="text-white font-medium">
              {schedule.filter(m => m.is_home).length}
            </span> home · <span className="text-white font-medium">
              {schedule.filter(m => !m.is_home).length}
            </span> away
          </span>
        </div>
      </div>

      <div className="orange-divider mb-6" />

      {/* Match cards */}
      <div className="flex flex-col gap-4">
        {loading
          ? Array(4).fill(0).map((_, i) => <SkeletonCard key={i} className="h-48" />)
          : schedule.map(match => (
            <MatchCard
              key={match.id}
              match={match}
              isNext={nextMatch?.id === match.id}
            />
          ))
        }
      </div>

      {schedule.length === 0 && !loading && (
        <div className="text-center py-16 text-srh-ash">
          <div className="text-4xl mb-3">📅</div>
          <p className="font-display text-2xl tracking-wider">SCHEDULE COMING SOON</p>
        </div>
      )}
    </div>
  )
}
