import { useApi } from '../hooks/useApi'

export default function WeatherWidget({ city }) {
  const { data, loading } = useApi(`/weather/${city || 'hyderabad'}`, { deps: [city] })

  if (loading) {
    return (
      <div className="flex items-center gap-3 px-4 py-3 rounded-xl border border-srh-charcoal-border bg-srh-charcoal-light">
        <div className="shimmer w-10 h-10 rounded-lg" />
        <div>
          <div className="shimmer h-3 w-24 rounded mb-2" />
          <div className="shimmer h-4 w-16 rounded" />
        </div>
      </div>
    )
  }

  if (!data || data.error) return null

  const rainColor = data.match_rain_probability_pct > 50
    ? 'text-blue-400'
    : data.match_rain_probability_pct > 25
      ? 'text-yellow-400'
      : 'text-green-400'

  return (
    <div className="flex items-center gap-4 px-4 py-3 rounded-xl border border-srh-charcoal-border bg-srh-charcoal-light">
      <span className="text-3xl">{data.icon}</span>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-srh-ash truncate">{data.venue}</p>
        <p className="text-white font-medium text-sm mt-0.5">{data.condition}</p>
      </div>
      <div className="text-right shrink-0">
        <p className="font-mono text-lg text-white font-medium">
          {data.temperature_c !== null ? `${data.temperature_c}°C` : '—'}
        </p>
        <p className={`text-xs font-mono ${rainColor}`}>
          {data.match_rain_probability_pct}% rain
        </p>
      </div>
      {data.play_likely !== undefined && (
        <div className={`px-2 py-1 rounded text-xs font-mono border ${
          data.play_likely
            ? 'text-green-400 border-green-400/30 bg-green-400/10'
            : 'text-blue-400 border-blue-400/30 bg-blue-400/10'
        }`}>
          {data.play_likely ? 'PLAY ON' : 'RAIN RISK'}
        </div>
      )}
    </div>
  )
}
