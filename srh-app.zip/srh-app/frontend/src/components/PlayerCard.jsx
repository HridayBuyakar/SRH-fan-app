import { useState } from 'react'

const ROLE_COLORS = {
  'Batter': 'text-yellow-400 border-yellow-400/40 bg-yellow-400/10',
  'Bowler': 'text-blue-400 border-blue-400/40 bg-blue-400/10',
  'All-Rounder': 'text-srh-orange border-srh-orange/40 bg-srh-orange/10',
  'WK-Batter': 'text-purple-400 border-purple-400/40 bg-purple-400/10',
}

const ROLE_ICONS = {
  'Batter': '🏏',
  'Bowler': '⚾',
  'All-Rounder': '⚡',
  'WK-Batter': '🧤',
}

function StatPill({ label, value, highlight = false }) {
  if (value === null || value === undefined) return null
  return (
    <div className={`flex flex-col items-center px-3 py-2 rounded-lg border ${
      highlight
        ? 'border-srh-orange/50 bg-srh-orange/10'
        : 'border-srh-charcoal-border bg-srh-charcoal'
    }`}>
      <span className={`font-mono font-medium text-sm ${highlight ? 'text-srh-orange' : 'text-white'}`}>
        {value}
      </span>
      <span className="font-body text-xs text-srh-ash mt-0.5 whitespace-nowrap">{label}</span>
    </div>
  )
}

export default function PlayerCard({ player, onClose }) {
  const [tab, setTab] = useState('batting')
  const s = player.t20_stats
  const roleColor = ROLE_COLORS[player.role] || 'text-srh-ash border-srh-ash/40 bg-srh-ash/10'
  const roleIcon = ROLE_ICONS[player.role] || '🏏'
  const isBowler = player.role === 'Bowler'
  const defaultTab = isBowler ? 'bowling' : 'batting'

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}>
      <div
        className="relative w-full max-w-lg bg-srh-charcoal-mid border border-srh-charcoal-border rounded-2xl overflow-hidden animate-slide-up"
        onClick={e => e.stopPropagation()}
      >
        {/* Header strip */}
        <div className="relative h-1.5 w-full bg-srh-charcoal-border">
          <div className="absolute left-0 top-0 h-full bg-srh-orange" style={{ width: '100%' }} />
        </div>

        {/* Top section */}
        <div className="p-6 pb-4">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-srh-ash hover:text-white transition-colors text-xl leading-none"
          >
            ×
          </button>

          <div className="flex items-start gap-4">
            {/* Avatar placeholder */}
            <div className="w-16 h-16 rounded-xl bg-srh-charcoal border border-srh-charcoal-border flex items-center justify-center text-3xl shrink-0">
              {roleIcon}
            </div>

            <div className="flex-1 min-w-0">
              {/* Badges row */}
              <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                <span className={`stat-chip ${roleColor}`}>{player.role}</span>
                {player.is_captain && (
                  <span className="stat-chip text-srh-gold border-srh-gold/40 bg-srh-gold/10">
                    ©️ CAPTAIN
                  </span>
                )}
                {player.is_overseas && (
                  <span className="stat-chip text-srh-ash border-srh-charcoal-border">
                    🌏 OVERSEAS
                  </span>
                )}
              </div>

              <h2 className="font-display text-3xl tracking-wider text-white truncate">
                {player.name.toUpperCase()}
              </h2>

              <div className="flex items-center gap-3 mt-1 text-srh-ash text-sm">
                <span>{player.nationality}</span>
                {player.jersey_number && (
                  <>
                    <span className="text-srh-charcoal-border">•</span>
                    <span className="font-mono text-srh-orange">#{player.jersey_number}</span>
                  </>
                )}
                {player.ipl_price_cr && (
                  <>
                    <span className="text-srh-charcoal-border">•</span>
                    <span className="font-mono text-srh-gold">₹{player.ipl_price_cr}Cr</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Bio */}
          <p className="mt-4 text-srh-ash-light text-sm leading-relaxed border-l-2 border-srh-orange/50 pl-3">
            {player.bio}
          </p>

          {/* Batting / bowling style */}
          <div className="mt-3 flex gap-4 text-xs text-srh-ash">
            {player.batting_style && <span>🏏 {player.batting_style}</span>}
            {player.bowling_style && <span>⚡ {player.bowling_style}</span>}
          </div>
        </div>

        <div className="orange-divider mx-6" />

        {/* Stats tabs */}
        <div className="px-6 pt-4 pb-1">
          <div className="flex gap-1 mb-4 bg-srh-charcoal rounded-lg p-1">
            {['batting', 'bowling'].map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 py-1.5 rounded-md font-display tracking-widest text-sm transition-all ${
                  tab === t
                    ? 'bg-srh-orange text-white'
                    : 'text-srh-ash hover:text-white'
                }`}
              >
                {t.toUpperCase()}
              </button>
            ))}
          </div>

          {tab === 'batting' ? (
            <div className="grid grid-cols-4 gap-2 pb-5">
              <StatPill label="Matches" value={s.matches} />
              <StatPill label="Runs" value={s.runs} highlight />
              <StatPill label="Avg" value={s.batting_avg} />
              <StatPill label="SR" value={s.batting_sr} highlight />
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-2 pb-5">
              <StatPill label="Wickets" value={s.wickets} highlight />
              <StatPill label="Avg" value={s.bowling_avg ?? '—'} />
              <StatPill label="Eco" value={s.economy ?? '—'} highlight />
              <StatPill label="Best" value={s.best_bowling ?? '—'} />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
