export function SkeletonCard({ className = '' }) {
  return (
    <div className={`srh-card p-5 ${className}`}>
      <div className="shimmer h-4 w-1/3 rounded mb-3" />
      <div className="shimmer h-6 w-2/3 rounded mb-4" />
      <div className="shimmer h-3 w-full rounded mb-2" />
      <div className="shimmer h-3 w-4/5 rounded" />
    </div>
  )
}

export function SkeletonRow() {
  return (
    <div className="flex items-center gap-4 p-4 border-b border-srh-charcoal-border">
      <div className="shimmer w-10 h-10 rounded-full shrink-0" />
      <div className="flex-1">
        <div className="shimmer h-4 w-1/3 rounded mb-2" />
        <div className="shimmer h-3 w-1/4 rounded" />
      </div>
      <div className="shimmer h-4 w-16 rounded" />
    </div>
  )
}
