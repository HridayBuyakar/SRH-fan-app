import { Routes, Route, NavLink, useLocation } from 'react-router-dom'
import SquadPage from './pages/SquadPage'
import SchedulePage from './pages/SchedulePage'
import MatchPage from './pages/MatchPage'

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-srh-charcoal-border bg-srh-charcoal/90 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-6 flex items-center justify-between h-16">

        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-srh-orange flex items-center justify-center shadow-[0_0_15px_rgba(255,107,0,0.6)]">
            <span className="text-sm">🔥</span>
          </div>
          <div>
            <span className="font-display text-2xl tracking-widest text-white">SRH</span>
            <span className="font-display text-2xl tracking-widest text-srh-orange ml-2">HQ</span>
          </div>
        </div>

        {/* Nav links */}
        <div className="flex items-center gap-8">
          <NavLink
            to="/"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            SQUAD
          </NavLink>
          <NavLink
            to="/schedule"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            SCHEDULE
          </NavLink>
          <NavLink
            to="/match"
            className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
          >
            LIVE
          </NavLink>
        </div>

        {/* Season badge */}
        <div className="hidden sm:flex items-center gap-2 border border-srh-orange/40 rounded px-3 py-1">
          <span className="w-2 h-2 rounded-full bg-srh-orange score-live"></span>
          <span className="font-mono text-xs text-srh-orange tracking-widest">IPL 2026</span>
        </div>
      </div>
    </nav>
  )
}

export default function App() {
  return (
    <div className="min-h-screen bg-srh-charcoal">
      <Navbar />
      <main className="pt-16">
        <Routes>
          <Route path="/" element={<SquadPage />} />
          <Route path="/schedule" element={<SchedulePage />} />
          <Route path="/match" element={<MatchPage />} />
        </Routes>
      </main>
    </div>
  )
}
