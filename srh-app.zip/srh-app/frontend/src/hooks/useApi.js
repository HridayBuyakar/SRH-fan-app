import { useState, useEffect, useCallback } from 'react'

const BASE = '/api'

export function useApi(endpoint, options = {}) {
  const { deps = [], immediate = true } = options
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(immediate)
  const [error, setError] = useState(null)

  const fetch_ = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`${BASE}${endpoint}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json()
      setData(json)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [endpoint, ...deps])

  useEffect(() => {
    if (immediate) fetch_()
  }, [fetch_])

  return { data, loading, error, refetch: fetch_ }
}

export function usePolling(endpoint, intervalMs = 30000) {
  const { data, loading, error, refetch } = useApi(endpoint)
  useEffect(() => {
    const id = setInterval(refetch, intervalMs)
    return () => clearInterval(id)
  }, [refetch, intervalMs])
  return { data, loading, error, refetch }
}
