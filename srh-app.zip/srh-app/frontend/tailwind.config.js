/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        srh: {
          orange: '#FF6B00',
          'orange-hot': '#FF4500',
          'orange-glow': '#FF8C00',
          'orange-dim': '#CC5500',
          charcoal: '#0D0D0D',
          'charcoal-mid': '#1A1A1A',
          'charcoal-light': '#252525',
          'charcoal-border': '#333333',
          ash: '#8A8A8A',
          'ash-light': '#BDBDBD',
          gold: '#FFD700',
        },
      },
      fontFamily: {
        display: ['Bebas Neue', 'Impact', 'sans-serif'],
        body: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-orange': 'pulse-orange 2s ease-in-out infinite',
        'slide-up': 'slide-up 0.5s ease-out forwards',
        'fade-in': 'fade-in 0.4s ease-out forwards',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        'pulse-orange': {
          '0%, 100%': { boxShadow: '0 0 10px rgba(255, 107, 0, 0.3)' },
          '50%': { boxShadow: '0 0 30px rgba(255, 107, 0, 0.8)' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'glow': {
          '0%': { textShadow: '0 0 10px rgba(255, 107, 0, 0.5)' },
          '100%': { textShadow: '0 0 30px rgba(255, 107, 0, 1), 0 0 60px rgba(255, 107, 0, 0.5)' },
        },
      },
      backgroundImage: {
        'orange-radial': 'radial-gradient(ellipse at top, #FF4500 0%, #0D0D0D 60%)',
        'card-gradient': 'linear-gradient(135deg, #1A1A1A 0%, #252525 100%)',
        'hero-gradient': 'linear-gradient(180deg, rgba(255,107,0,0.15) 0%, #0D0D0D 100%)',
      },
    },
  },
  plugins: [],
}
