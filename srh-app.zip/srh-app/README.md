# 🔥 SRH Fan App — Orange Army HQ

A React + FastAPI fan app for the 2026 IPL season.

## APIs Used
| API | Purpose | Key Required |
|---|---|---|
| CricketData.org | Live scores, matches | Yes (free signup at cricketdata.org) |
| Open-Meteo | Match-day weather | No key needed |
| GNews (future) | SRH news feed | Yes (free) |

---

## Project Structure
```
srh-app/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app + CORS
│   │   ├── data/
│   │   │   ├── squad.py         # SRH 2026 squad seed data
│   │   │   └── schedule_data.py # IPL 2026 schedule seed data
│   │   └── routers/
│   │       ├── squad.py         # GET /api/squad/
│   │       ├── schedule.py      # GET /api/schedule/
│   │       ├── matches.py       # GET /api/matches/live (proxies CricketData.org)
│   │       └── weather.py       # GET /api/weather/{city} (Open-Meteo)
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── App.jsx              # Router + Navbar
    │   ├── pages/
    │   │   ├── SquadPage.jsx    # Squad list + player card modal
    │   │   ├── SchedulePage.jsx # Match cards with weather
    │   │   └── MatchPage.jsx    # Live scorecard + tables
    │   ├── components/
    │   │   ├── PlayerCard.jsx   # Full player stats modal
    │   │   ├── WeatherWidget.jsx
    │   │   └── Skeleton.jsx     # Loading placeholders
    │   └── hooks/
    │       └── useApi.js        # Fetch + polling hooks
    ├── tailwind.config.js
    └── vite.config.js           # Proxies /api → FastAPI
```

---

## Setup

### Backend
```bash
cd srh-app/backend

# Create venv
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Mac/Linux

pip install -r requirements.txt

# Copy .env and add your CricketData.org key (optional)
copy .env.example .env

# Run
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd srh-app/frontend
npm install
npm run dev
# Opens at http://localhost:5173
```

---

## Pages
| Route | Page |
|---|---|
| `/` | Squad — full SRH 2026 roster with T20 stats, filterable by role. Click any player for detailed card. |
| `/schedule` | Schedule — all SRH IPL 2026 fixtures with countdown, weather, venue. |
| `/match` | Live — live scorecard proxied from CricketData.org. Falls back to mock data if no API key. |

---

## Notes
- **No API key?** The live match page serves realistic mock data. Everything else (squad, schedule, weather) works with zero config.
- **Rate limiting:** Live match page polls every 30s to stay within the 100 hits/day free tier.
- **Weather:** Fully free via Open-Meteo. No key, no limits.

---

*🧡 Go SRH!*
