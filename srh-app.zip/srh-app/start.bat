@echo off
echo.
echo  ==========================================
echo   SRH Fan App - Starting...
echo  ==========================================
echo.

:: Check venv exists
if not exist backend\venv\Scripts\activate.bat (
    echo ERROR: Backend not set up yet. Please run setup.bat first.
    pause
    exit /b 1
)

:: Check node_modules exists
if not exist frontend\node_modules (
    echo ERROR: Frontend not set up yet. Please run setup.bat first.
    pause
    exit /b 1
)

echo Starting FastAPI backend on http://localhost:8000 ...
start "SRH Backend" cmd /k "cd backend && venv\Scripts\activate.bat && uvicorn app.main:app --reload --port 8000"

:: Small delay so backend starts before frontend opens
timeout /t 2 /nobreak >nul

echo Starting React frontend on http://localhost:5173 ...
start "SRH Frontend" cmd /k "cd frontend && npm run dev"

timeout /t 3 /nobreak >nul

echo.
echo  ==========================================
echo   App running!
echo   Frontend : http://localhost:5173
echo   API docs : http://localhost:8000/docs
echo  ==========================================
echo.

:: Open browser
start http://localhost:5173
