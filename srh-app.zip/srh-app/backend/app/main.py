from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import squad, schedule, matches, weather

app = FastAPI(title="SRH Fan App API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(squad.router, prefix="/api/squad", tags=["Squad"])
app.include_router(schedule.router, prefix="/api/schedule", tags=["Schedule"])
app.include_router(matches.router, prefix="/api/matches", tags=["Matches"])
app.include_router(weather.router, prefix="/api/weather", tags=["Weather"])

@app.get("/")
def root():
    return {"message": "SRH Fan App API 🧡", "status": "online"}
