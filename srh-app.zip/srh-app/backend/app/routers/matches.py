from fastapi import APIRouter, HTTPException
import httpx
import os
from dotenv import load_dotenv

load_dotenv()

router = APIRouter()

CRICKET_API_KEY = os.getenv("CRICKETDATA_API_KEY", "")
CRICKET_API_BASE = "https://api.cricapi.com/v1"

# Mock live match for development / when no API key is set
MOCK_LIVE_MATCH = {
    "id": "mock_001",
    "name": "Royal Challengers Bengaluru vs Sunrisers Hyderabad",
    "status": "SRH need 42 runs in 24 balls",
    "venue": "M. Chinnaswamy Stadium, Bengaluru",
    "date": "2026-03-28",
    "dateTimeGMT": "2026-03-28T14:00:00",
    "teams": ["Royal Challengers Bengaluru", "Sunrisers Hyderabad"],
    "teamInfo": [
        {"name": "Royal Challengers Bengaluru", "shortname": "RCB"},
        {"name": "Sunrisers Hyderabad", "shortname": "SRH"},
    ],
    "score": [
        {"r": 182, "w": 7, "o": 20.0, "inning": "Royal Challengers Bengaluru Inning 1"},
        {"r": 141, "w": 3, "o": 16.0, "inning": "Sunrisers Hyderabad Inning 1"},
    ],
    "batting": [
        {"batsman": "Travis Head", "r": 67, "b": 38, "4s": 6, "6s": 4, "sr": "176.32"},
        {"batsman": "Abhishek Sharma", "r": 42, "b": 28, "4s": 4, "6s": 2, "sr": "150.00"},
    ],
    "bowling": [
        {"bowler": "Mohammed Siraj", "o": "4.0", "m": 0, "r": 38, "w": 1, "eco": "9.50"},
        {"bowler": "Josh Hazlewood", "o": "4.0", "m": 0, "r": 29, "w": 2, "eco": "7.25"},
    ],
    "toss": {"winner": "Royal Challengers Bengaluru", "decision": "bat"},
    "matchStarted": True,
    "matchEnded": False,
    "is_mock": True,
}

@router.get("/live")
async def get_live_matches():
    if not CRICKET_API_KEY:
        return {"matches": [MOCK_LIVE_MATCH], "is_mock": True}
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{CRICKET_API_BASE}/currentMatches",
                params={"apikey": CRICKET_API_KEY, "offset": 0},
                timeout=10,
            )
            data = resp.json()
            if data.get("status") != "success":
                return {"matches": [MOCK_LIVE_MATCH], "is_mock": True}

            srh_matches = [
                m for m in data.get("data", [])
                if any("sunrisers" in t.lower() or "srh" in t.lower()
                       for t in m.get("teams", []))
            ]
            return {"matches": srh_matches or [MOCK_LIVE_MATCH], "is_mock": len(srh_matches) == 0}
    except Exception as e:
        return {"matches": [MOCK_LIVE_MATCH], "is_mock": True, "error": str(e)}


@router.get("/scorecard/{match_id}")
async def get_scorecard(match_id: str):
    if match_id == "mock_001" or not CRICKET_API_KEY:
        return MOCK_LIVE_MATCH

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{CRICKET_API_BASE}/match_scorecard",
                params={"apikey": CRICKET_API_KEY, "id": match_id},
                timeout=10,
            )
            return resp.json().get("data", {})
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Cricket API error: {str(e)}")
