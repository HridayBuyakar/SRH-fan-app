from fastapi import APIRouter, HTTPException
from app.data.squad import SRH_SQUAD

router = APIRouter()

@router.get("/")
def get_squad():
    return {"squad": SRH_SQUAD, "total": len(SRH_SQUAD)}

@router.get("/{player_id}")
def get_player(player_id: int):
    player = next((p for p in SRH_SQUAD if p["id"] == player_id), None)
    if not player:
        raise HTTPException(status_code=404, detail="Player not found")
    return player

@router.get("/role/{role}")
def get_by_role(role: str):
    filtered = [p for p in SRH_SQUAD if p["role"].lower() == role.lower()]
    return {"players": filtered, "role": role, "count": len(filtered)}
