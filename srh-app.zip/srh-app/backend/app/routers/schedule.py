from fastapi import APIRouter
from app.data.schedule_data import SRH_SCHEDULE
from datetime import date

router = APIRouter()

@router.get("/")
def get_schedule():
    today = date.today().isoformat()
    for match in SRH_SCHEDULE:
        if match["date"] < today:
            if match["result"] is None:
                match["status"] = "completed"
        elif match["date"] == today:
            match["status"] = "today"
    return {"schedule": SRH_SCHEDULE, "total": len(SRH_SCHEDULE)}

@router.get("/next")
def get_next_match():
    today = date.today().isoformat()
    upcoming = [m for m in SRH_SCHEDULE if m["date"] >= today]
    if not upcoming:
        return {"match": None}
    return {"match": sorted(upcoming, key=lambda x: x["date"])[0]}
