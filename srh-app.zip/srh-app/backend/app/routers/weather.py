from fastapi import APIRouter
import httpx

router = APIRouter()

# Venue coordinates for SRH schedule
VENUES = {
    "hyderabad": {"lat": 17.4065, "lon": 78.5480, "name": "Rajiv Gandhi International Cricket Stadium"},
    "bengaluru": {"lat": 12.9789, "lon": 77.5917, "name": "M. Chinnaswamy Stadium"},
    "kolkata": {"lat": 22.5645, "lon": 88.3433, "name": "Eden Gardens"},
    "mumbai": {"lat": 19.0446, "lon": 72.8259, "name": "Wankhede Stadium"},
    "chennai": {"lat": 13.0632, "lon": 80.2789, "name": "M. A. Chidambaram Stadium"},
    "delhi": {"lat": 28.6358, "lon": 77.2245, "name": "Arun Jaitley Stadium"},
    "jaipur": {"lat": 26.8954, "lon": 75.8069, "name": "Sawai Mansingh Stadium"},
    "lucknow": {"lat": 26.8500, "lon": 80.9462, "name": "BRSABV Ekana Cricket Stadium"},
    "ahmedabad": {"lat": 23.0902, "lon": 72.0951, "name": "Narendra Modi Stadium"},
    "mohali": {"lat": 30.6763, "lon": 76.7091, "name": "Punjab Cricket Association Stadium"},
}

OPEN_METEO_BASE = "https://api.open-meteo.com/v1/forecast"

WMO_CODES = {
    0: {"desc": "Clear sky", "icon": "☀️"},
    1: {"desc": "Mainly clear", "icon": "🌤️"},
    2: {"desc": "Partly cloudy", "icon": "⛅"},
    3: {"desc": "Overcast", "icon": "☁️"},
    45: {"desc": "Foggy", "icon": "🌫️"},
    48: {"desc": "Freezing fog", "icon": "🌫️"},
    51: {"desc": "Light drizzle", "icon": "🌦️"},
    61: {"desc": "Slight rain", "icon": "🌧️"},
    63: {"desc": "Moderate rain", "icon": "🌧️"},
    65: {"desc": "Heavy rain", "icon": "🌧️"},
    80: {"desc": "Rain showers", "icon": "🌦️"},
    95: {"desc": "Thunderstorm", "icon": "⛈️"},
}

@router.get("/{city}")
async def get_weather(city: str):
    city_key = city.lower()
    venue = VENUES.get(city_key)
    if not venue:
        venue = VENUES["hyderabad"]

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                OPEN_METEO_BASE,
                params={
                    "latitude": venue["lat"],
                    "longitude": venue["lon"],
                    "current": "temperature_2m,relative_humidity_2m,precipitation,weathercode,windspeed_10m",
                    "hourly": "precipitation_probability,temperature_2m",
                    "forecast_days": 1,
                    "timezone": "Asia/Kolkata",
                },
                timeout=10,
            )
            data = resp.json()
            current = data.get("current", {})
            wmo = current.get("weathercode", 0)
            weather_info = WMO_CODES.get(wmo, {"desc": "Unknown", "icon": "🌡️"})

            # Get afternoon (match time ~3-7pm) rain probability
            hourly = data.get("hourly", {})
            times = hourly.get("time", [])
            rain_probs = hourly.get("precipitation_probability", [])

            # Find 15:00–19:00 slots
            match_rain_probs = []
            for i, t in enumerate(times):
                hour = int(t.split("T")[1].split(":")[0])
                if 15 <= hour <= 19 and i < len(rain_probs):
                    match_rain_probs.append(rain_probs[i])

            avg_rain_prob = (
                round(sum(match_rain_probs) / len(match_rain_probs))
                if match_rain_probs else 0
            )

            return {
                "venue": venue["name"],
                "city": city_key,
                "temperature_c": current.get("temperature_2m"),
                "humidity_pct": current.get("relative_humidity_2m"),
                "wind_kmh": current.get("windspeed_10m"),
                "precipitation_mm": current.get("precipitation"),
                "condition": weather_info["desc"],
                "icon": weather_info["icon"],
                "match_rain_probability_pct": avg_rain_prob,
                "play_likely": avg_rain_prob < 40,
            }
    except Exception as e:
        return {
            "venue": venue["name"],
            "city": city_key,
            "error": str(e),
            "temperature_c": None,
            "condition": "Unavailable",
            "icon": "❓",
        }
